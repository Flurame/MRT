import csv
import os
import sqlite3


db_name = "mebel.db"
import_folder = "import"


con = sqlite3.connect(db_name)
cur = con.cursor()

cur.execute("PRAGMA foreign_keys = ON")


cur.execute("""
CREATE TABLE IF NOT EXISTS role (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS app_user (
    id INTEGER PRIMARY KEY,
    role_id INTEGER NOT NULL,
    login TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    last_name TEXT NOT NULL,
    first_name TEXT NOT NULL,
    middle_name TEXT,
    FOREIGN KEY (role_id) REFERENCES role(id)
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS category (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS maker (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS supplier (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS unit (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS product (
    id INTEGER PRIMARY KEY,
    article TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    category_id INTEGER NOT NULL,
    description TEXT,
    maker_id INTEGER NOT NULL,
    supplier_id INTEGER NOT NULL,
    price REAL NOT NULL,
    unit_id INTEGER NOT NULL,
    stock_count INTEGER NOT NULL,
    discount REAL NOT NULL,
    photo TEXT,
    FOREIGN KEY (category_id) REFERENCES category(id),
    FOREIGN KEY (maker_id) REFERENCES maker(id),
    FOREIGN KEY (supplier_id) REFERENCES supplier(id),
    FOREIGN KEY (unit_id) REFERENCES unit(id)
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS order_status (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS pickup_point (
    id INTEGER PRIMARY KEY,
    address TEXT NOT NULL
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS order_head (
    id INTEGER PRIMARY KEY,
    status_id INTEGER NOT NULL,
    pickup_point_id INTEGER NOT NULL,
    order_date TEXT NOT NULL,
    pickup_date TEXT,
    FOREIGN KEY (status_id) REFERENCES order_status(id),
    FOREIGN KEY (pickup_point_id) REFERENCES pickup_point(id)
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS order_product (
    id INTEGER PRIMARY KEY,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    count INTEGER NOT NULL,
    FOREIGN KEY (order_id) REFERENCES order_head(id),
    FOREIGN KEY (product_id) REFERENCES product(id)
)
""")


cur.execute("INSERT OR IGNORE INTO role VALUES (1, 'client')")
cur.execute("INSERT OR IGNORE INTO role VALUES (2, 'manager')")
cur.execute("INSERT OR IGNORE INTO role VALUES (3, 'admin')")


def read_text(file_name):
    try:
        file = open(file_name, "r", encoding="utf-8-sig", newline="")
        text = file.read()
        file.close()
        return text
    except UnicodeDecodeError:
        file.close()

    file = open(file_name, "r", encoding="cp1251", newline="")
    text = file.read()
    file.close()
    return text


def get_delimiter(text):
    first_line = text.split("\n")[0]

    if ";" in first_line:
        return ";"

    if "\t" in first_line:
        return "\t"

    return ","


def add_rows(file_name, table_name, column_names):
    path = os.path.join(import_folder, file_name)

    if os.path.exists(path) == False:
        print("no file:", path)
        return

    text = read_text(path)
    delimiter = get_delimiter(text)
    rows = text.splitlines()
    reader = csv.reader(rows, delimiter=delimiter)

    sql_columns = ", ".join(column_names)
    sql_questions = ", ".join(["?"] * len(column_names))
    sql = "INSERT OR IGNORE INTO " + table_name + " (" + sql_columns + ") VALUES (" + sql_questions + ")"

    for row in reader:
        if len(row) == 0:
            continue

        if row[0].lower() == column_names[0].lower():
            continue

        row = row[:len(column_names)]

        while len(row) < len(column_names):
            row.append("")

        cur.execute(sql, row)

    print("imported:", path)


os.makedirs(import_folder, exist_ok=True)

add_rows("role_import.csv", "role", ["id", "name"])
add_rows("user_import.csv", "app_user", ["id", "role_id", "login", "password", "last_name", "first_name", "middle_name"])
add_rows("category_import.csv", "category", ["id", "name"])
add_rows("maker_import.csv", "maker", ["id", "name"])
add_rows("supplier_import.csv", "supplier", ["id", "name"])
add_rows("unit_import.csv", "unit", ["id", "name"])
add_rows("product_import.csv", "product", ["id", "article", "name", "category_id", "description", "maker_id", "supplier_id", "price", "unit_id", "stock_count", "discount", "photo"])
add_rows("order_status_import.csv", "order_status", ["id", "name"])
add_rows("pickup_point_import.csv", "pickup_point", ["id", "address"])
add_rows("order_import.csv", "order_head", ["id", "status_id", "pickup_point_id", "order_date", "pickup_date"])
add_rows("order_product_import.csv", "order_product", ["id", "order_id", "product_id", "count"])


con.commit()
con.close()

print("done")
